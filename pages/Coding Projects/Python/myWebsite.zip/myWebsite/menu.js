document.querySelector('select').onchange = function() {
         document.querySelector('p').style.fontSize = this.value;
       };
/*
navigator.geolocation.getCurrentPosition(function(position){
  document.write(position.coords.latitude + ", "+ position.coords.longitude);
});
*/