def main():
    text = input("Enter text: ")
    gradeLevel = evaluate(text)
    if (gradeLevel < 1 ):
        print(f"Grade level: 1")
    elif (gradeLevel > 16):
        print(f"Grade level: 16+")
    else:
        print(f"Grade level: {gradeLevel}")
        
def evaluate(text):
    words = text.strip().split(" ")

    numWords = len(words)
    numSen = countSentences(words)
    numLetters = countLetters(words)
    
    L = numLetters/(numWords/100)
    S = numSen/(numWords/100)
    
    return int(0.0588 * L - 0.296 * S - 15.8)
  
def countLetters(arr):
    count = 0;
    for i in range(len(arr)):
        for i in arr[i]:
            if ( not(i == ".") and  not(i == "?")  ):
                count+=1
    return count
    
def countSentences(arr):
    count = 0;
    for i in range(len(arr)):
        if (arr[i].endswith(".") or arr[i].endswith("?")):
            count+= 1
    return count
    
main()
