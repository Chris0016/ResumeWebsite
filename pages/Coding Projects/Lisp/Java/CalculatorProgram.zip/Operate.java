import java.lang.*;

public class Operate {
	double num1;
	double num2;
	
	public Operate()
	{
		num1 = 0;
		num2 = 0;
		
	}
	public Operate(double fn, double sn)
	{
		num1 = fn;
		num2 = sn;
		
	}
	public Operate(double fn){
	    num1 = fn;
	}
	
	public double add(){
		return num1 + num2;
	}
	public double subtract(){
		return num1 - num2;
	}
	public double multiply(){
		return num1*num2;
	}
	public double divide(){
		return num1/num2;
	}
	public double sqrt(){
		return Math.sqrt(num1);
	}
	public double power(){
		return Math.pow(num1,num2);
	}
}