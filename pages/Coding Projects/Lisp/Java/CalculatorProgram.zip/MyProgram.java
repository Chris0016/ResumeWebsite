import java.util.Scanner;
import java.lang.*;
import java.util.ArrayList;

public class MyProgram
{
	public static void main(String[] args){
	Scanner input = new Scanner(System.in);
	System.out.println("     MATH CALCULATOR\n");

	System.out.println("   Operation      Input ");
	System.out.println("  ---------------------");
	System.out.println("   Square root   sqrt");
	System.out.println("   Exponent      power");
	System.out.println("   Add           add");
	System.out.println("   Subtract      sub");
	System.out.println("   Multiply      mul");
	System.out.println("   Divide        div\n");
	
	
	
	while(true){
		
		System.out.print("  Enter the operation: ");
		String math= input.nextLine();
		
		while(true){
		if (math.equals("sqrt") || math.equals("power") || math.equals("add")|| math.equals("sub") || math.equals("mul")|| math.equals("div") )
		break; 

		else{
			System.out.println("  Not an operation");
			System.out.print("  Enter an operation: ");
		}
		math = input.nextLine();
		}


		System.out.print("  Enter number: ");
		double firstNum = input.nextDouble();
			
			/*
			try{
                double firstNum = input.nextDouble();
				String.valueOf(firstNum);
				break;
			}
			catch (Exception e){
				System.out.print("Not a number");
				System.out.print("Enter a number: ");
				
			}
			*/
			
		
		

		if (math.equals("sqrt")){
			Operate compute = new Operate(firstNum);
			System.out.println("   Result: "+compute.sqrt()+"\n");
		}
		else if(math.equals("power")){
			System.out.print("  Enter the power: ");
			double expo = input.nextDouble();
			Operate compute = new Operate(firstNum, expo);
			System.out.println(" "+compute.power());
		}
	
		//call out.println
		else{
			System.out.print("  Enter second number: ");
			double secNum = input.nextDouble();
			Operate compute = new Operate(firstNum, secNum);
			if (math.equals("add")){
				System.out.println("   Result: "+compute.add()+"\n");
			}
			else if (math.equals("sub")){
				System.out.println("   Result: "+compute.subtract()+"\n");
			}else if (math.equals("mul")){
				System.out.println("   Result: "+compute.multiply()+"\n");
			}else if (math.equals("div")){
				
				while (true){
				if (secNum == 0){
					System.out.println("   Can't divide by zero!");

				}
				else{
					System.out.println("   Result: " + compute.divide()+"\n");
					break;
				}
					System.out.print("  Enter another dividend: "); 
					secNum = input.nextDouble();
					compute = new Operate(firstNum, secNum);
					

			}
		}
		}
	
		//handle division by zero when dividing
		System.out.print("  Continue? (\"no\" to quit):");
		input.nextLine();
		String xfactor = input.nextLine();
		if (xfactor.equals("No") || xfactor.equals("no")){
			break;
		}
		else{
			System.out.println();
		}
    }
	input.close();

	}
}