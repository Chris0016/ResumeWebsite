import java.util.Scanner;

public class MyProgram
{
    public static void main(String[] args)
    {
        
        Scanner input = new Scanner(System.in);
        System.out.println("Virtual library app");
        
        System.out.println("Enter a number");
        int guess,dev, attempts;
        final int LUCKY = 5;
        attempts= 1;
        
        while (true){
            System.out.print("Enter number: ");
            guess = input.nextInt();
            
            if (guess == LUCKY){
                System.out.println("Corrrecccctt!!!");
                break;
            }
            dev = Math.abs(LUCKY - guess);
            if (dev <= 10){
                System.out.println("Very Hot");
            }
            else if (dev <= 20) System.out.println("Warming up");
            else if (dev <= 40) System.out.println("Cold");
            else{
                System.out.println("Antarctica");
            }
            attempts++;
        }
        System.out.println("After "+attempts+" attempt(s) you got it");
        System.exit(0);
    
    }
}