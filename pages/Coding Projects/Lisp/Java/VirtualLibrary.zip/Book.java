public class Book
{
    String title;
    String category;
    String author;
    int id;
    int date;
    
    public Book(String title , String category , String author , int id , int date){
        this.title = title;
        this.category = category;
        this.author = author;
        this.id = id;
        this.date = date;
    }
}