import java.util.ArrayList;
public class Library{

    ArrayList<Book> library;
    
    
    public Library( ){
        //Instatiate a library
        library = new ArrayList<Book>();
        
    }
    
    public void loadLib(String filename){
        //TODO  
    }
    
    
    public void addBook(String title , String category , String author, int id, int date  ){
        library.add(new Book(title , category , author , id , date));
    }
    
    public ArrayList<Book> getBook(String title){
        ArrayList<Book> results = new ArrayList<>();
        
        for (int i =0; i < library.size() ; i++){
            Book temp = library.get(i);
            String holdTitle = temp.title;
            if (holdTitle.equals(title)) results.add(temp);
        
        }
        return results;
    }
    
    public ArrayList<Book> getBook(int id){
        ArrayList<Book> results = new ArrayList<>();
        
        for (Book h : library){

            int holdID = h.id;
            if (holdID == (id)) results.add(h);
        
        }
        return results;
    }
    
    public ArrayList<Book> getAuthor(String author){
         ArrayList<Book> results = new ArrayList<>();
        for (Book h : library){
            if(h.author.equals(author))
                results.add(h);
        }
        return results;
    }
    
    class Book{
    String title;
    String category;
    String author;
    int id;
    int date;
    
    public Book(String title , String category , String author , int id , int date){
        this.title = title;
        this.category = category;
        this.author = author;
        this.id = id;
        this.date = date;
    }
   }
}