import java.util.Scanner;
import java.util.ArrayList;

public class MyProgram{
     public static UnoDeck game;
     public  static UserPlay player;
    
    public static boolean order = true;
    public static boolean conTinue = true; 
	static ArrayList<ArrayList<String>>order1;
	static byte indexM;

	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
        
         
        game = new UnoDeck();
        player = new UserPlay();
        
        game.cpu1Deck.add("Alex");//Give cpu a name value at the end of string 
		game.cpu2Deck.add("James");//REMINDER: IF ITERATING ALWAYS START AT 1.
      
      
		game.setCardSuit(); 
	
		game.setDeck(game.playerDeck);
	    game.setDeck(game.cpu1Deck);
		game.setDeck(game.cpu2Deck);
		
	   /*
	    //game.cpu1Deck.add("RSkip");
		game.cpu1Deck.add("BSkip");
		game.cpu1Deck.add("GSkip");
		game.cpu1Deck.add("YSkip");
		game.cpu1Deck.add("Y1");
	   */
		
		game.setPlayedDeck();
		game.setTC();
        
        order1 = new ArrayList<>(1);
    	 
    	order1.add(UnoDeck.cpu1Deck);
    	order1.add(UnoDeck.cpu2Deck);
    	order1.add(UnoDeck.playerDeck);
        
        
		
		
		System.out.println(" Welcome to the Uno game");
		System.out.println(" Rules: \n1. Multiple cards that macth the number of the top card can be put down or One card matching the color of the top card can be put down.\n2. No pick and play\n3. If no cards on deck match the top card then: \n A Card will be drawn automatically\n Only one card is picked up(regardless if it matches or not) ");
	     /* With plus cards as long as the first mathes the color many can be played because they maatch values/symbols
	        With regular cards this isn't the case.
	     */
		 indexM = 0;
		 
		while (conTinue == true){
			System.out.println("\n"+"Order value: "+ order);
			
			if(order == true){
				System.out.println("Top card:"+ UnoDeck.lastCard(UnoDeck.playedDeck)+"\n");
				System.out.println("length of deck for next player: "+ order1.get(indexM).size()  );
				//order1.get(indexM);
				if ((order1.get(indexM).get(0)).equals("James") || (order1.get(indexM).get(0)).equals("Alex"))
                    game.cpuPlay(order1.get(indexM));
			    else
			        player.play();
			}
			
			else if (order == false){
			
				System.out.println("Top card (reverse order): "+ UnoDeck.lastCard(UnoDeck.playedDeck)+"\n");
				//order1.get(indexM);
				if ((order1.get(indexM).get(0)).equals("James") || (order1.get(indexM).get(0)).equals("Alex"))
                    game.cpuPlay(order1.get(indexM));
			    else
			        player.play();
		        
		        }
		        //To check for the order value.
		        
		      
		        if (order == true){ 
		            indexM++;
		            
		            }
		        else{
		            indexM--;
		            
		        }
		        if (indexM >= 3){ indexM = 0; }
			     else if (indexM < 0 ) {indexM = 2;}
		}
		
	}
	
	
	
	
}
/*
Create a stacking metod that works for both the Reverse, skip, and Plus:

 Reverse:
    changes the value of the order variable everytime a card is played

 Skip: 
    Changes the value of the variable indexM which is responsible for specifying which player will be played
    
 Plus:
    Stacking- holds off the card from being played unless the next player has a plus. For user, we have 
    to check if the user has any pluses. If he or she does, we display his/her set , ask the user for those cards and then HOLD THEM.
    Next, we repeat.
*/