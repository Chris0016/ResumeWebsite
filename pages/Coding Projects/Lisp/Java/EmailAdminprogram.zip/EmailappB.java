import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class EmailappB{
    
    private String firstName;
    private String lastName;
    private String password;
    private String alternateEmail;
    private byte defaultPasswordLength = 8;
    public static int mailBoxCapacity;
    private String department = "none";
    private String company = "Google";
    private String email;
    Scanner input = new Scanner(System.in);
   
    public EmailappB(String firstName, String lastName){
        this.firstName = firstName;
        this.lastName = lastName;
        
        //System.out.println("EMAIL CREATED: " + this.firstName + " "+ this.lastName);
        
        this.department =  departmentSet();
        this.email = companyEmail();
        this.password = passwordSet(defaultPasswordLength);
        input.nextLine();
        System.out.println("Name : "+ this.firstName + " "+this.lastName);
        System.out.println("Company Email: "+ this.email);
        System.out.println("Password: "+this.password);
        
        System.out.print("Mailbox Capacity: " + mailBoxCapacity + "mB");
        
    }
    
    public String departmentSet(){
       
        
        System.out.print("Department codes:\n0 for Accounting\n1 for Development\n2 for Sales\n3 for none\nEnter department code:");
        
        byte dptNum = input.nextByte();
        
        if(dptNum==0){ return "Acc";}
        else if(dptNum == 1){return "Dev";}
        else if (dptNum == 2){return "Sales";}
        else{ return "worker";}
        
    }
    
    public String passwordSet(byte length){
        //In the future use generex form github to generate a random sequence
        String charactrs = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        String password = "";
        while (length > 0){
            password += charactrs.charAt( (int)(Math.random()*charactrs.length()) );
            length--;
        }
        return password;
    }
    public int setmailboxSize(int mailBoxCapacity){
        return mailBoxCapacity;
    }
    /*
    public String comapany(){
        return this.company = input.nextLine();
    }
    
    //technically the company name is already given so this method isn't needed
    */
    public String companyEmail(){
        return (this.firstName).trim().toLowerCase() + "."+(this.lastName).trim().toLowerCase() + "@"+department+"." +company+".com";
    }
    
    public void changeEmail(){
        //this.email = userInput;
        System.out.print("Enter new username: ");
        this.email = input.nextLine()  + "@"+department+"." +company+".com";
        System.out.print("New email: "+ email);
    
    
    }
    
    
    
    public String changePassword(){
        Pattern pasCheck = Pattern.compile("[A-Za-z0-9]{6,}");
        Matcher mtch;
        String newpassword;
        while(true){
            
        System.out.println("Enter new password(length > 6, must have at least 2 digits and numbers: ");
        newpassword = input.nextLine();
        mtch = pasCheck.matcher(newpassword);
        if (mtch.matches()){
            int wCount = 0;
            int lCount = 0;
            for (int i = 0 ; i < newpassword.length() ; i++){
                if( Character.isLetter(newpassword.charAt(i) ))
                    wCount++;
                
                    
                else if (Character.isDigit(newpassword.charAt(i)))
                     lCount++;
                
                   
            }
            if (wCount > 2 &&lCount > 2){
                this.password = newpassword;
            System.out.println("Password changed");
            break;
            }
            else{
                System.out.println("Must have at least 2 numbers and digits\nEnter another password");
                
            }
        }
            
        else{
            System.out.println("Must be at least 6 characters and at least 2 numbers and digits");
        }
        }
    return password;
    
    }
    
    
    
    private void printPassword(){
        System.out.println("Password: "+ password);
    }
    public void printUsername(){
        System.out.println("Email: "+ email);
    }
    
    //create mailbox capacity method
    //create alternate email method
    //show info methods
    //change password method
    //show all info method
}

