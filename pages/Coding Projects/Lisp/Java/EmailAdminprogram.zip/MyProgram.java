import java.util.Scanner;
public class MyProgram
{
    public static void main(String[] args)
    {
       Scanner input = new Scanner(System.in);
       System.out.print("Enter number of employees: ");
       EmailappB.mailBoxCapacity  = input.nextInt();
       input.nextLine();
      
       for (int i = 0; i < EmailappB.mailBoxCapacity; i++){
       System.out.print("Enter first name: ");
       String user1name = input.nextLine();
       
       System.out.print("Enter last name: ");
       String user1lname = input.nextLine();
       
       
       EmailappB employeeInfo = new EmailappB(user1name , user1lname);
       System.out.println();
       
       employeeInfo.changePassword();
       }
      
       
      //employeeInfo.changeEmail();
       //employeeInfo.changePassword();
       //employeeInfo.printPassword();
       //employeeInfo.printUsername();
    }
}