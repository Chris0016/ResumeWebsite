import java.lang.*;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class MyProgram
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("	Valid email checker\n");
        System.out.println("  Username requires");
        System.out.println(" At least 8 Characters\n At least 1 digit\n At least 1 letter\n");
        System.out.println(" Valid domains: \n gmail \n hotmail \n outlook\n");

       while(true){
        System.out.print(" Enter a username: ");
        String userInput = input.nextLine();  
        
        Pattern regexName = Pattern.compile("[A-Za-z0-9]{7,}@(gmail|hotmail|outlook)\\.com");
        Matcher nameMatch = regexName.matcher(userInput);
        
        if (nameMatch.matches()){
        	int lCount = 0;
        	int nCount = 0;
        	for (int i = 0; i < userInput.indexOf("@"); i++){
        		if ( Character.isDigit(userInput.charAt(i))  ){
        			nCount++;
        		}else if( Character.isLetter(userInput.charAt(i))) {
        			lCount++;
        		}
        	}
        	if (lCount > 0 && nCount > 0 ){
        		System.out.println(" Valid username");
        		System.out.print(" Another username?(n to quit): ");
        		char cont = input.next().charAt(0);
        		input.nextLine();
        		if (cont =='n'){
            		input.close();
            		System.out.println();
            		System.out.print(" Thanks");
            		break;
        			}
        	}
        	else{
        		System.out.println(" Not a strong username(need at least 1 number or letter)");
        	}   
        }
        else{
         	System.out.println(" Not a valid username");
            }       
       }
    }
}
/* This project aims to use Regex as its motor to create a "secure" system to 
hold usernames and passwords of the users. 


*/