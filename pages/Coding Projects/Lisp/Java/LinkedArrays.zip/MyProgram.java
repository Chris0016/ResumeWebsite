import java.util.Arrays;

public class MyProgram
{
    public static void main(String[] args)
    {
        
        
        String[][] categories = new String[3][];
        categories[0] = new String[50];
        categories[1] = new String[17];
        categories[2] = new String[33];
        
        categories[0][0] = "Even";
        categories[1][0] = "Odd";
        categories[2][0] = "Prime";
        short index1 = 0;
        short index2 = 0;
        short index3 = 0;

        for (int i = 1; i < 101; i++){
            
            if (i % 2 ==0 ){
                  categories[0][index1] = String.valueOf(i);
                  index1++;
            }
            else if(i % 3 == 0 ){
                categories[1][index2] = String.valueOf(i);
                  index2++;
            }
            else{
                categories[2][index3] = String.valueOf(i);
                index3++;
            }
              
        }
        System.out.print(Arrays.deepToString(categories));
   
   
    }
   
}